package com.example.android.worldcup;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

import com.example.android.quizapp.R;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    // Global variable to count the correct answers
    int counter = 0;

    // numberCorrectAnswer method to inrement the counuter if the correct checkBox is checked
    private int numberCorrectAnswer (){
        CheckBox ch1 = (CheckBox) findViewById(R.id.Answer_1_B);
        if(ch1.isChecked()){
            counter+=1;
        }
        CheckBox ch2 = (CheckBox) findViewById(R.id.Answer_2_B);
        if(ch2.isChecked()){
            counter+=1;
        }
        CheckBox ch3 = (CheckBox) findViewById(R.id.Answer_3_A);
        if(ch3.isChecked()){
            counter+=1;
        }
        CheckBox ch4 = (CheckBox) findViewById(R.id.Answer_4_B);
        if(ch4.isChecked()){
            counter+=1;
        }
        CheckBox ch5 = (CheckBox) findViewById(R.id.Answer_5_C);
        if(ch5.isChecked()){
            counter+=1;
        }
        CheckBox ch6 = (CheckBox) findViewById(R.id.Answer_6_B);
        if(ch6.isChecked()){
            counter+=1;
        }
        CheckBox ch7 = (CheckBox) findViewById(R.id.Answer_7_B);
        if(ch7.isChecked()){
            counter+=1;
        }
        CheckBox ch8 = (CheckBox) findViewById(R.id.Answer_8_B);
        if(ch8.isChecked()){
            counter+=1;
        }
        return counter;

    }
    //call the numberCorrectAnswer() and analyse it's return
    // <= 1 use answer in singular > 1 to use it in plural
    // then call the display message method
    private void correctAnswer(){
        int correctAns=numberCorrectAnswer();
        String message="";

        displayMessage(message);
        if(correctAns <=1){
            message="You have " + correctAns + " correct answer";

        }else if(correctAns==8){
            message="Congrat you won";
        }else {
            message="You have "+ correctAns+ " correct answers";
        }

        displayMessage(message);
    }

    private void displayMessage(String message) {
        TextView result = (TextView) findViewById(R.id.correction);
        result.setText(message);
    }

}
